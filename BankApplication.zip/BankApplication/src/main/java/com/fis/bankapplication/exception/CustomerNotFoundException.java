package com.fis.bankapplication.exception;

public class CustomerNotFoundException extends Exception{
	public CustomerNotFoundException(String string) {
		super(string);
	}
}

