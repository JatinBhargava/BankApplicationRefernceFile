package com.fis.bankapplication.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.service.AccountService;
import com.fis.bankapplication.service.AccountServiceImpl;

/*
 * Routes:
 * /accounts - add account
 * /accounts/getAccount/{accountId}
 * /accounts/deleteAccount/{accountId}
 * /accounts/updateAccountBalance/{accountId}
 * /accounts/getAllAccountsByRange/{minBal}/{maxBal}
 * /accounts/getAllAccounts
 */

@RestController
@RequestMapping("/accounts")
public class AccountController {

	@Autowired
	private AccountService accountService;
	
	@PostMapping
	public String addAccount(@RequestBody Account account) {
			accountService.addAccount(account);
			return "Account added to the Database";
	}
	
	@GetMapping("/getAccount/{accountId}")
	public Optional<Account> getAccountDetails(@PathVariable("accountId") int accountId) {
		return accountService.getAccountByAccountId(accountId);
	}
	
	@DeleteMapping("/deleteAccount/{accountId}")
	public String deleteAccountDetails(@PathVariable("accountId") int accountId) {
		accountService.deleteAccount(accountId);
		return "Account Deleted with id:" +  accountId;
	}
	
	@PutMapping("/updateAccountBalance/{accountId}")
	public String updateAccountDetails(
			@PathVariable("accountId") int accountId,
			@RequestParam double newBalance
			) {
		accountService.updateAccount(accountId, newBalance);
		return "Account amount Updated with id:" + accountId;
	}

	@GetMapping("/getAllAccountsByRange/{minBal}/{maxBal}")
	public List<Account> getProducts(@PathVariable("minBal") double minBal, @PathVariable("maxBal") double maxBal) {
		return accountService.getAllAccountsByBalanceRange(minBal, maxBal);
	}
	
	@GetMapping("/getAllAccounts")
	public List<Account> getProducts() {
		return accountService.getAllAccounts();
	}
}
