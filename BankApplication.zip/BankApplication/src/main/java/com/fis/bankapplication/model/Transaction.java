package com.fis.bankapplication.model;

import java.util.Date;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Transaction {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long transactionId;
	private double amount;
	private Date transcationDate;
	private String modeOfTransaction;
	private int fromAccount;
	private int toAccount;
	
	@ManyToOne
	@JoinColumn(name = "accountId")
	private Account account;

	public Transaction(long transactionId, double amount, Date transcationDate, String modeOfTransaction,
			int fromAccount, int toAccount, Account account) {
		super();
		this.transactionId = transactionId;
		this.amount = amount;
		this.transcationDate = transcationDate;
		this.modeOfTransaction = modeOfTransaction;
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
		this.account = account;
	}

	public Transaction() {
		// TODO Auto-generated constructor stub
	}

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Date getTranscationDate() {
		return new Date();
	}

	public void setTranscationDate(Date transcationDate) {
		this.transcationDate = transcationDate;
	}

	public String getModeOfTransaction() {
		return modeOfTransaction;
	}

	public void setModeOfTransaction(String modeOfTransaction) {
		this.modeOfTransaction = modeOfTransaction;
	}

	public int getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(int fromAccount) {
		this.fromAccount = fromAccount;
	}

	public int getToAccount() {
		return toAccount;
	}

	public void setToAccount(int toAccount) {
		this.toAccount = toAccount;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}
}
