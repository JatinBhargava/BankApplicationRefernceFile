package com.fis.bankapplication.service;

import java.util.List;
import java.util.Optional;

import com.fis.bankapplication.model.Account;

public interface AccountService {
	public abstract String addAccount(Account account);
	public abstract Optional<Account> getAccountByAccountId(int accountId);
	public abstract String updateAccount(int accountId,double amount);
	public abstract String deleteAccount(int accountId);
	public abstract List<Account> getAllAccountsByBalanceRange (double minBal,double maxBal);
	public abstract List<Account> getAllAccounts();
}
