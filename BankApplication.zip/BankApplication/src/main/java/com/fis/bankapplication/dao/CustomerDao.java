package com.fis.bankapplication.dao;
import com.fis.bankapplication.exception.CustomerNotFoundException;
import com.fis.bankapplication.exception.EmptyField;
import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Customer;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerDao extends JpaRepository<Customer,Integer>{
//	public abstract String updateUser(int customerId,String name, String address) throws CustomerNotFoundException;
//	public abstract String deleteUser(int customerId) throws CustomerNotFoundException;
//	public abstract Customer getUser(int customerId) throws CustomerNotFoundException;
}
