package com.fis.bankapplication.service;

import java.util.List;
import java.util.Optional;

import com.fis.bankapplication.exception.CustomerNotFoundException;
import com.fis.bankapplication.exception.InsufficientBalance;
import com.fis.bankapplication.model.Transaction;

public interface TransactionService {
	public abstract void deposit(int accountId,double amount);
	public abstract void withdraw(int accountId,double amount) throws InsufficientBalance;
	public abstract void fundTransfer(int fromAccountId,int toAccountId,double amount) throws InsufficientBalance;
	public abstract List<Transaction> getAllTranscation();
//	public abstract List<Transaction> getAllTranscationByAccountId(int accountId);
}
