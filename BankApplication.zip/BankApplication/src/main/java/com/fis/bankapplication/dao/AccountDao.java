package com.fis.bankapplication.dao;

import java.util.List;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.fis.bankapplication.model.Account;

public interface AccountDao extends JpaRepository<Account,Integer>{
	
	@Modifying
	@Query("UPDATE Account ba SET ba.balance = :newBalance where ba.id = :accountId")
	public abstract String updateAccount(@Param("accountId") int accountId,@Param("newBalance") double amount);
	
	@Modifying
	@Query("SELECT a FROM Account a WHERE a.balance >= :minBal AND a.balance <= :maxBal")
	public abstract List<Account> getAllAccountsByBalanceRange (double minBal,double maxBal);
}
